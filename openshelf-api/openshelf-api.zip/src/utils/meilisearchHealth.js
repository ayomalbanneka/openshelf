const { meiliClient } = require('../config/meilisearch') // adjust to your actual export

const getMeilisearchHealth = async () => {
  const start = Date.now()
  try {
    const health = await meiliClient.health() // { status: 'available' }
    const latencyMs = Date.now() - start

    const stats = await meiliClient.getStats().catch(() => null)
    const resourceIndex = stats?.indexes?.resources ?? null

    return {
      status: health.status === 'available' ? 'healthy' : 'degraded',
      latencyMs,
      documentCount: resourceIndex?.numberOfDocuments ?? null,
      isIndexing: resourceIndex?.isIndexing ?? false,
    }
  } catch (err) {
    return {
      status: 'down',
      latencyMs: Date.now() - start,
      error: err.message,
    }
  }
}

module.exports = { getMeilisearchHealth }