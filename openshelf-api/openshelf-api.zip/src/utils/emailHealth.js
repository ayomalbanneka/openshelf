const RESEND_API_KEY = process.env.RESEND_API_KEY

const getEmailHealth = async () => {
  const start = Date.now()
  try {
    const res = await fetch('https://api.resend.com/domains', {
      headers: { Authorization: `Bearer ${RESEND_API_KEY}` },
    })
    const latencyMs = Date.now() - start

    if (!res.ok) {
      return { status: 'degraded', latencyMs, httpStatus: res.status }
    }

    const data = await res.json()
    const domain = data.data?.find((d) => d.name === process.env.EMAIL_FROM_DOMAIN)

    return {
      status: 'healthy',
      latencyMs,
      domainVerified: domain?.status === 'verified',
    }
  } catch (err) {
    return { status: 'down', latencyMs: Date.now() - start, error: err.message }
  }
}

module.exports = { getEmailHealth }